const express = require("express");
const knex = require("knex");
const errors = require("http-errors");
const createHttpError = require("http-errors");

const app = express();

app.use(express.json);
app.use(express.urlencoded({extended : true}));

const PORT = 3000;

const conn = knex({
    client : "mysql2",
    connection : {
        host: "localhost",
        user: "root",
        password: "mcbrs",
        database: "loja"
    }
});

app.get("/", (req, res)=>{
    res.json({resposta: "Welcome to my store"})
});

app.get( "/produtos", (req, res, next) =>{
    conn("produto")
        .then(dados => res.json(dados))
        .catch(next);
});

app.get( "/produtos/:idProd", (req, res, next) =>{
    const id = req.params.idProd;
    conn("produto")
        .where("id", id)
        .first()
        .then(dados =>{
            if(!dados){
                return next(errors(404, "The product you are searching for doesn't exist"));
            }
            res.json(next);
        })
        .catch(next);
});


app.listen(PORT, ()=>{
    console.log(`Store is being executed in http://localhost:${PORT}`)
});
















